
# Vektörel Kurs Yapay Zeka Projesi

Bu uygulama, kişinin cinsiyet, boy, kilo ve spor durumu gibi verilerini isteyip karşılığında 0 ve 100 arasından bir puan veren bir masaüstü uygulamadır. Puanlamaya yapay zekanın linear regresyon kullanması ile ulaşılır.

Verilen kutucukların her birinin doldurulması zorunludur. Sonra alttaki "Sonuç" düğmesine tıklanır ve sonucunuz düğmenin altında gösterilir.

Anlatım videosu: https://youtu.be/4p-CB2pvI50
